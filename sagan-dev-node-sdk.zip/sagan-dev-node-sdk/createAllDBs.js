/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var dbmgr = require('./cloudant-dal/db-manager.js');

//dbmgr.loadFileData("/Users/deanh/Documents/Wearables/sagan-sdk/cloudant-dal/data-files/example.json", function(err, result) {
dbmgr.createAll(function(err, result) {
    if (err) {
        console.log("err: " + err);
    } else {
        console.log("res: " + result);
    }
});
