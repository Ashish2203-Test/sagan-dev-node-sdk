/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var dbmgr = require('../cloudant-dal/db-manager.js');
var pendingUserBL = require('../business-logic/pendinguser.bl.js');
var userBL = require('../business-logic/user.bl.js');
var async = require('async');
var testTools = require('./testTools.js');
var path = require('path');
var dataFilePath = path.join(__dirname, "bl", "pendinguser.json");
var iotfClient = require('../iotfClient.js');

describe('Pending User BL', function () {
    var docId = "";

    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        //testTools.disableLogs();
        dbmgr.create(userBL._name, function (err) {
            expect(err).to.be.null;
            dbmgr.create(pendingUserBL._name, function (err) {
                expect(err).to.be.null;
                done();
            });
        });
    });


    afterEach(function (done) {
        dbmgr.delete(userBL._name, function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;
            dbmgr.delete(pendingUserBL._name, function (err) {
                expect(err).to.be.null;
                done();
            });
        });
    });

    after(function () {
    });

    var loadTestByName = function (testName, callback) {
        dbmgr.loadFileData(dataFilePath, testName, function (err, results) {
            expect(err).to.be.null;
            callback(err, results)
        });
    };


    describe('pendingUser.approvePendingUser', function () {
        it('user.approvePendingUser user already exists', function (done) {
            var testName = "approvePendingUserUserAlreadyExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                pendingUserBL.approvePendingUser(docToInsert, function (err, iotResult) {
                    expect(err).not.to.be.null;
                    expect(iotResult).to.be.null;

                    done();
                });
            });
        });

        it('user.approvePendingUser delete user that exists', function (done) {
            var testName = "approvePendingUserDeleteUserThatExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];
                var docToInsert = require(dataFilePath)[testName][0].data[0];
                var iotpOutput = 'output';

                // Mocking functions:
                var oldFunc = iotfClient.createDevice;
                iotfClient.createDevice = function (post_data, callback) {
                    callback(null, iotpOutput);
                };

                pendingUserBL.getByID(insertedDoc.id, function (err, getUser) {
                    expect(err).to.be.null;
                    expect(getUser).not.to.be.null;

                    pendingUserBL.approvePendingUser(getUser, function (err, iotResult) {
                        iotfClient.createDevice = oldFunc;

                        expect(err).to.be.null;
                        expect(iotResult).not.to.be.null;
                        expect(iotResult).to.be.equal(iotpOutput);

                        pendingUserBL.getByID(insertedDoc.id, function (err, getUser) {
                            expect(err).not.to.be.null;
                            expect(getUser).to.be.null;

                            done();
                        });
                    });
                });
            });
        });

        it('user.approvePendingUser delete user that does not exist', function (done) {
            var testName = "approvePendingUserDeleteUserThatDoesNotExist";

            var docToInsert = require(dataFilePath)[testName][0].data[0];
            var iotpOutput = 'output';

            // Mocking functions:
            var oldFunc = iotfClient.createDevice;
            iotfClient.createDevice = function (post_data, callback) {
                callback(null, iotpOutput);
            };

            pendingUserBL.approvePendingUser(docToInsert, function (err, iotResult) {
                iotfClient.createDevice = oldFunc;

                expect(err).not.to.be.null;
                expect(err).to.contain("approved user, but failed to remove it from db - ");
                expect(iotResult).not.to.be.null;
                expect(iotResult).to.be.equal(iotpOutput);

                done();
            });
        });

        it('user.approvePendingUser user is undefined', function (done) {
            var testName = "approvePendingUserUserIsUndefined";

            pendingUserBL.approvePendingUser(undefined, function (err, iotResult) {
                expect(err).not.to.be.null;
                expect(iotResult).to.be.null;

                done();
            });
        });
    });

    describe('pendingUser.getByUsername', function () {
        it('pendingUser.getByUsername single doc', function (done) {
            var testName = "getByUsernameSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];

                pendingUserBL.getByID(insertedDoc.id, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    pendingUserBL.getByUsername(getResult.username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });

        it('pendingUser.getByUsername multiple doc', function (done) {
            var testName = "getByUsernameMultipleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];

                pendingUserBL.getByID(insertedDoc.id, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    pendingUserBL.getByUsername(getResult.username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });

        it('pendingUser.getByUsername non existing doc', function (done) {
            var testName = "getByUsernameNonExistingDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                pendingUserBL.getByUsername("asdf", function (err, getUser) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Got too many users or none')
                    expect(getUser).to.be.null;

                    done();
                });
            });
        });
    });
});