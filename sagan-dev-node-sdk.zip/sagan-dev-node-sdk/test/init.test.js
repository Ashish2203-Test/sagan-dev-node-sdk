/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var config = require('../config.js');
var expect  = require("chai").expect;
var path = require('path');

// Root-Initialization , done once for all tests in this directory
before(function(done){
  this.timeout(30000); // A very long environment setup.
  var prefix = process.env.WF_DEPLOY_TARGET_PREFIX || 'dean';
  config.populateGlobalCredentialsFromServer(prefix+'-api', done);
});


describe('Check Configuration file ', function(){
  before(function(){
  var wfconfig = {};
      wfconfig = config.loadRootConfigFile();
  });

  describe('Configuration file Environement Check', function(){
    it('confiuguarion file exists', function(done){
      //console.log("INFO, module = init.test, msg = Configuration File Used  " + process.env.WF_CONFIG_FILE_PATH);
      expect(process.env.WF_CONFIG_FILE_PATH).not.to.be.empty;
      done()
    });
  });

});
