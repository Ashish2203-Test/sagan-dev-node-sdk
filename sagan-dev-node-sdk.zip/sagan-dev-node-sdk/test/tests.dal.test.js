/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var credentials = require('../credentials.js');
var chance = require('chance');
var cloudant = require('cloudant');
var baseDAL = require('../cloudant-dal/base.dal.js');
var async = require('async');
var testTools = require('./testTools.js');

describe('Cloudant Dal', function () {
    var dal = {};
    var cloudantCred = {};
    var dbName = "";
    var docId = "";

    this.timeout(10000);

    beforeEach(function () {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        dbName = "test" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 6});
        dal = new baseDAL(dbName);
        cloudantCred = credentials.getCredentialsByServiceName('cloudantNoSQLDB');
        if (!cloudantCred) {
            throw new Error("Missing Cloudant credentials");
        }

    });

    afterEach(function (done) {
        testTools.disableLogs();
        dal.deleteDB(function (err, result) {
            testTools.enableLogs();
            done();
        });
    });

    after(function () {
        // testTools.clearDBs(function () {
        //     done();
        // });
    });

    describe('Cloudant BaseDAL.doesBDExist', function () {

        it('BaseDAL.doesDBExist true (should exist)', function (done) {

            var cloudantDB = cloudant({
                url: cloudantCred.url,
                plugin: 'retry'
            });

            // Create DB, using cloudant
            cloudantDB.db.create(dbName, function (err, result) {
                expect(err).to.be.null;

                //Check whether db Exists
                dal.doesDBExist(function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.true;
                    done();
                });
            });
        });

        it('BaseDAL.doesDBExist false (should not exist)', function (done) {

            //Check whether DB exists, should NOT exist
            dal.doesDBExist(function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.false;
                done();
            });

        });

    });

    describe('Cloudant BaseDAL.createDB', function () {

        it('BaseDAL.createDB success', function (done) {

            //Create DB
            dal.createDB(function (err) {
                expect(err).to.be.null;
                //Checking whether DB exists (should exist)
                dal.doesDBExist(function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.true;
                    done();
                });

            });
        });

    });

    describe('Cloudant BaseDAL.deleteDB', function () {

        it('BaseDAL.deleteDB success', function (done) {

            this.timeout(4000);
            //Create DB
            dal.createDB(function (err) {
                expect(err).to.be.null;
                // Delete Created DB in step 1
                dal.deleteDB(function (err) {
                    expect(null).to.be.null;
                    //Check wether DB exists (should NOT)
                    dal.doesDBExist(function (err, result) {
                        expect(err).to.be.null;
                        expect(result).to.be.false;
                        done();
                    });

                });
            });
        });

    });

    describe('Cloudant BaseDAL.selectByID', function () {

        it('BaseDAL.selectByID success', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var cloudantDB = cloudant({
                    url: cloudantCred.url,
                    plugin: 'retry'
                });

                var testDB = cloudantDB.db.use(dbName);
                var newDoc = {"testID": docId};

                //Insert Entity
                testDB.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;

                    //Check Entity
                    dal.selectByID(id, function (err, doc) {
                        //Check whether received entity matches the inserted Entity
                        expect(err).to.be.null;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.testID).to.be.equal(docId);
                        done();
                    });

                });

            });
        });

        it('BaseDAL.selectByID fail', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var id = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 15});
                // Select non-exist entity and check if there isn't such
                dal.selectByID(id, function (err, doc) {
                    expect(err).to.exist;
                    expect(err.reason).to.equal("missing");
                    expect(doc).to.be.null;
                    console.log(doc);

                    done();
                });

            });
        });

    });

    describe('Cloudant BaseDAL.Insert', function () {

        it('BaseDAL.Insert success', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var newDoc = {'testID': docId};

                // Insert Entity
                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;

                    //Check if selected entity matches the inserted entity
                    dal.selectByID(id, function (err, doc) {
                        expect(err).to.be.null;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.testID).to.be.equal(docId);
                        done();
                    });
                });
            });

        });

        it('BaseDAL.Insert By _id success', function (done) {

            var _id = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});

            dal.createDB(function (err) {
                expect(err).to.be.null;

                // Here we added specific cloudant ID to the entity
                var newDoc = {'testID': docId, "_id": _id};

                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    //Check whether selected entity matches the inserted entity
                    dal.selectByID(_id, function (err, doc) {
                        expect(err).to.be.null;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.testID).to.be.equal(docId);
                        done();
                    });

                });

            });
        });

        it('BaseDAL.Several Inserts By _id success', function (done) {

            //Same as last test by checking several times

            var calls = [];

            var _id1 = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
            var _id2 = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
            var _id3 = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var newDoc1 = {'testID': docId + "1", "_id": _id1};
                var newDoc2 = {'testID': docId + "2", "_id": _id2};
                var newDoc3 = {'testID': docId + "3", "_id": _id3};

                calls.push(function (asyncCallback) {
                    dal.insert(newDoc1, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');
                        asyncCallback(null, true);

                    });
                });

                calls.push(function (asyncCallback) {
                    dal.insert(newDoc2, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');
                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    dal.insert(newDoc3, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');
                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    dal.selectByID(_id1, function (err, doc) {
                        expect(err).to.be.null;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.testID).to.be.equal(newDoc1.testID);
                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    dal.selectByID(_id2, function (err, doc) {
                        expect(err).to.be.null;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.testID).to.be.equal(newDoc2.testID);
                        asyncCallback(null, true);
                    });
                });

                calls.push(function (asyncCallback) {
                    dal.selectByID(_id3, function (err, doc) {
                        expect(err).to.be.null;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.testID).to.be.equal(newDoc3.testID);
                        asyncCallback(null, true);
                    });
                });

                async.series(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });

            });
        });

    });

    describe('Cloudant BaseDAL.insertBulk', function () {

        it('BaseDAL.insertBulk success', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var calls = [];

                var _id1 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id2 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });

                var newDocs = [{'testID': docId + "1", 'idIndex': "1", "_id": _id1}, {
                    'testID': docId + "2",
                    'idIndex': "2",
                    "_id": _id2
                }];

                dal.insertBulk(newDocs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(newDocs.length);

                    calls.push(function (asyncCallback) {
                        dal.selectByID(_id1, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');
                            var docIdIndex = docId + doc.idIndex;
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.selectByID(_id2, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');
                            var docIdIndex = docId + doc.idIndex;
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });
                });
            });
        });

    });

    describe('Cloudant BaseDAL.Delete', function () {

        it('BaseDAL.Delete success (_id/_rev)', function (done) {

            dal.createDB(function (err, result) {

                expect(err).to.be.null;

                var newDoc = {'testID': docId};

                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;
                    result._id = result.id;
                    result._rev = result.rev;

                    // Deleting Entity
                    dal.delete(result, function (err, response) {
                        expect(err).to.be.null;

                        //CHeck if entity exists (should not)
                        dal.selectByID(id, function (err, doc) {
                            expect(err).to.exist;
                            expect(err).not.to.be.empty;
                            expect(err.reason).to.equal("deleted");
                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.Delete success (id/rev)', function (done) {

            dal.createDB(function (err, result) {

                expect(err).to.be.null;

                var newDoc = {'testID': docId};

                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;

                    // Deleting Entity
                    dal.delete(result, function (err, response) {
                        expect(err).to.be.null;

                        //CHeck if entity exists (should not)
                        dal.selectByID(id, function (err, doc) {
                            expect(err).to.exist;
                            expect(err).not.to.be.empty;
                            expect(err.reason).to.equal("deleted");
                            done();
                        });
                    });
                });
            });
        });
    });

    describe('Cloudant BaseDAL.deleteBulk', function () {

        it('BaseDAL.deleteBulk success (_id/_rev)', function (done) {
            dal.createDB(function (err) {
                expect(err).to.be.null;

                var _id1 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id2 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });

                var newDocs = [{'testID': docId + "1", 'idIndex': "1", "_id": _id1}, {
                    'testID': docId + "2",
                    'idIndex': "2",
                    "_id": _id2
                }];

                dal.insertBulk(newDocs, function (err, insertResult) {
                    expect(err).to.be.null;
                    expect(insertResult).to.be.a('array');
                    expect(insertResult).not.to.be.empty;
                    expect(insertResult.length).to.be.equal(newDocs.length);

                    var deleteDocs = [];
                    insertResult.forEach(function (row) {
                        deleteDocs.push({
                            _id: row.id,
                            _rev: row.rev
                        });
                    });

                    dal.deleteBulk(deleteDocs, function (err, result) {
                        expect(err).to.be.null;

                        var calls = [];

                        calls.push(function (asyncCallback) {
                            dal.selectByID(_id1, function (err, doc) {
                                expect(err).not.to.be.null;
                                expect(err.reason).to.equal("deleted");
                                expect(doc).to.be.null;
                                asyncCallback(null, true);
                            });
                        });

                        calls.push(function (asyncCallback) {
                            dal.selectByID(_id2, function (err, doc) {
                                expect(err).not.to.be.null;
                                expect(err.reason).to.equal("deleted");
                                expect(doc).to.be.null;
                                asyncCallback(null, true);
                            });
                        });

                        async.parallel(calls, function (err, result) {
                            expect(err).to.be.null;
                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.deleteBulk success (id/rev)', function (done) {
            dal.createDB(function (err) {
                expect(err).to.be.null;

                var _id1 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id2 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });

                var newDocs = [{'testID': docId + "1", 'idIndex': "1", "_id": _id1}, {
                    'testID': docId + "2",
                    'idIndex': "2",
                    "_id": _id2
                }];

                dal.insertBulk(newDocs, function (err, insertResult) {
                    expect(err).to.be.null;
                    expect(insertResult).to.be.a('array');
                    expect(insertResult).not.to.be.empty;
                    expect(insertResult.length).to.be.equal(newDocs.length);

                    var deleteDocs = [];
                    insertResult.forEach(function (row) {
                        deleteDocs.push({
                            id: row.id,
                            rev: row.rev
                        });
                    });

                    dal.deleteBulk(deleteDocs, function (err, result) {
                        expect(err).to.be.null;

                        var calls = [];

                        calls.push(function (asyncCallback) {
                            dal.selectByID(_id1, function (err, doc) {
                                expect(err).not.to.be.null;
                                expect(err.reason).to.equal("deleted");
                                expect(doc).to.be.null;
                                asyncCallback(null, true);
                            });
                        });

                        calls.push(function (asyncCallback) {
                            dal.selectByID(_id2, function (err, doc) {
                                expect(err).not.to.be.null;
                                expect(err.reason).to.equal("deleted");
                                expect(doc).to.be.null;
                                asyncCallback(null, true);
                            });
                        });

                        async.parallel(calls, function (err, result) {
                            expect(err).to.be.null;
                            done();
                        });
                    });
                });
            });
        });

    });

    describe('Cloudant BaseDAL.selectByAttribute', function () {
        it('BaseDAL.selectByAttribute single doc', function (done) {
            dal.createDB(function (err) {
                expect(err).to.be.null;
                var newDoc = {'testID': docId};

                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    dal.selectByAttribute("testID", docId, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).to.be.a('array');
                        expect(selectedDoc.length).to.be.equal(1);
                        expect(selectedDoc[0].testID).to.be.exist;
                        expect(selectedDoc[0].testID).to.be.equal(newDoc.testID);

                        done();
                    });
                });
            });
        });

        it('BaseDAL.selectByAttribute no docs (wrong value)', function (done) {
            dal.createDB(function (err) {
                expect(err).to.be.null;
                var newDoc = {'testID': docId};

                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    dal.selectByAttribute("testID", docId + "1", function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).to.be.a('array');
                        expect(selectedDoc).to.be.empty;

                        done();
                    });
                });
            });
        });

        it('BaseDAL.selectByAttribute no docs (wrong attribute)', function (done) {
            dal.createDB(function (err) {
                expect(err).to.be.null;
                var newDoc = {'testID': docId};

                dal.insert(newDoc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    dal.selectByAttribute("asdf", docId, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).to.be.a('array');
                        expect(selectedDoc).to.be.empty;

                        done();
                    });
                });
            });
        });

        it('BaseDAL.selectByAttribute multiple docs', function (done) {
            dal.createDB(function (err) {
                expect(err).to.be.null;
                var docs = [{'testID': docId, 'no': 1}, {'testID': docId, 'no': 2}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    dal.selectByAttribute("testID", docId, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).to.be.a('array');
                        expect(selectedDoc.length).to.be.equal(docs.length);
                        expect(selectedDoc[0].testID).to.be.exist;
                        expect(selectedDoc[0].testID).to.be.equal(docId);
                        expect(selectedDoc[0].no).to.be.equal(1);

                        expect(selectedDoc[1].testID).to.be.exist;
                        expect(selectedDoc[1].testID).to.be.equal(docId);
                        expect(selectedDoc[1].no).to.be.equal(2);

                        done();
                    });
                });
            });
        });
    });

    describe('Cloudant BaseDAL.update', function () {

        it('BaseDAL.Update field success', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var doc = {'testID': docId};

                dal.insert(doc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;

                    dal.selectByID(id, function (err, getDoc) {
                        expect(err).to.be.null;
                        expect(getDoc).not.to.be.null;

                        var newDocId = "newId" + new chance.Chance().string({
                                pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                                length: 14
                            });

                        getDoc.testID = newDocId;

                        dal.update(getDoc, function (err, result) {
                            expect(err).to.be.null;

                            dal.selectByID(id, function (err, doc) {
                                expect(err).to.be.null;
                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(newDocId);
                                done();
                            });
                        });
                    });
                });
            });
        });

        it('BaseDAL.Update field success (add new field)', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var doc = {'testID': docId};

                dal.insert(doc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;

                    dal.selectByID(id, function (err, getDoc) {
                        expect(err).to.be.null;
                        expect(getDoc).not.to.be.null;

                        var newDocId = "newId" + new chance.Chance().string({
                                pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                                length: 14
                            });

                        getDoc.newField = newDocId;

                        dal.update(getDoc, function (err, result) {
                            expect(err).to.be.null;

                            dal.selectByID(id, function (err, doc) {
                                expect(err).to.be.null;
                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docId);

                                expect(doc.newField).to.exist;
                                expect(doc.newField).not.to.be.empty;
                                expect(doc.newField).to.be.a('string');
                                expect(doc.newField).to.be.equal(newDocId);
                                done();
                            });
                        });
                    });
                });
            });
        });

        it('BaseDAL.Update field success (remove existing field)', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var newDocId = "newId" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var doc = {'testID': docId, 'newTestID': newDocId};

                dal.insert(doc, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    var id = result.id;

                    dal.selectByID(id, function (err, getDoc) {
                        expect(err).to.be.null;
                        expect(getDoc).not.to.be.null;

                        delete getDoc.newTestID;

                        dal.update(getDoc, function (err, result) {
                            expect(err).to.be.null;

                            dal.selectByID(id, function (err, doc) {
                                expect(err).to.be.null;
                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docId);

                                expect(doc.newTestID).not.to.exist;
                                done();
                            });
                        });
                    });
                });
            });
        });

    });

    describe('Cloudant BaseDAL.list', function () {

        it('BaseDAL.List success', function (done) {
            var calls = [];
            dal.createDB(function (err) {
                expect(err).to.be.null;

                var _id1 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id2 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id3 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var newDocs = [{'testID': docId + "1", 'idIndex': "1", "_id": _id1}, {
                    'testID': docId + "2",
                    'idIndex': "2",
                    "_id": _id2
                }, {'testID': docId + "3", 'idIndex': "3", "_id": _id3}];

                dal.insertBulk(newDocs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    dal.list(function (err, docs) {
                        expect(err).to.be.null;
                        expect(docs).to.be.a('array');
                        expect(docs).not.to.be.empty;
                        expect(docs.count).to.be.equal(newDocs.count);

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element._id === _id1;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');
                            var docIdIndex = docId + doc.idIndex;
                            expect(docIdIndex).to.be.equal(docId + "1");
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element._id === _id2;
                            })

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');
                            var docIdIndex = docId + doc.idIndex;
                            expect(docIdIndex).to.be.equal(docId + "2");
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element._id === _id3;
                            })

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');
                            var docIdIndex = docId + doc.idIndex;
                            expect(docIdIndex).to.be.equal(docId + "3");
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });

                        async.parallel(calls, function (err, result) {
                            expect(err).to.be.null;
                            done();
                        });
                    });
                });
            });
        });

    });

    describe('Cloudant BaseDAL.ListPaginated', function () {

        it('BaseDAL.ListPaginated success', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var newDocs = [];

                var _id1 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id2 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id3 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });
                var _id4 = "id" + new chance.Chance().string({
                        pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                        length: 14
                    });

                var newDocs = [{'testID': docId + "1", 'idIndex': "1", "_id": _id1}, {
                    'testID': docId + "2",
                    'idIndex': "2",
                    "_id": _id2
                }, {'testID': docId + "3", 'idIndex': "3", "_id": _id3}, {
                    'testID': docId + "4",
                    'idIndex': "4",
                    "_id": _id4
                }];

                var count = newDocs.length;
                var limit = 2;
                var calls = [];

                dal.insertBulk(newDocs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    var allDocs = [];

                    // Skip = Number of rows to skip, look inside at index
                    for (var skip = 0; skip < count; (skip = skip + limit)) {
                        (function (index) {
                            calls.push(function (asyncCallback) {
                                dal.listPaginated(limit, index, function (err, docs) {
                                    expect(err).to.be.null;
                                    expect(docs).not.to.be.empty;
                                    expect(docs.rows).to.be.exist;
                                    expect(docs.rows).to.be.a('array');
                                    expect(docs.rows.length).to.be.at.most(limit);
                                    allDocs = allDocs.concat(docs.rows);
                                    asyncCallback(null, true);
                                })
                            });
                        })(skip);
                    }

                    calls.push(function (asyncCallback) {
                        var doc = allDocs.find(function findElement(element) {
                            return element.doc._id === _id1;
                        }).doc;
                        expect(doc).not.to.be.undefined;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.idIndex).to.exist;
                        expect(doc.idIndex).not.to.be.empty;
                        expect(doc.idIndex).to.be.a('string');
                        var docIdIndex = docId + doc.idIndex;
                        expect(docIdIndex).to.be.equal(docId + "1");
                        expect(doc.testID).to.be.equal(docIdIndex);
                        asyncCallback(null, true);
                    });

                    calls.push(function (asyncCallback) {
                        var doc = allDocs.find(function findElement(element) {
                            return element.doc._id === _id2;
                        }).doc;
                        expect(doc).not.to.be.undefined;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.idIndex).to.exist;
                        expect(doc.idIndex).not.to.be.empty;
                        expect(doc.idIndex).to.be.a('string');
                        var docIdIndex = docId + doc.idIndex;
                        expect(docIdIndex).to.be.equal(docId + "2");
                        expect(doc.testID).to.be.equal(docIdIndex);
                        asyncCallback(null, true);
                    });

                    calls.push(function (asyncCallback) {
                        var doc = allDocs.find(function findElement(element) {
                            return element.doc._id === _id3;
                        }).doc;
                        expect(doc).not.to.be.undefined;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.idIndex).to.exist;
                        expect(doc.idIndex).not.to.be.empty;
                        expect(doc.idIndex).to.be.a('string');
                        var docIdIndex = docId + doc.idIndex;
                        expect(docIdIndex).to.be.equal(docId + "3");
                        expect(doc.testID).to.be.equal(docIdIndex);
                        asyncCallback(null, true);
                    });

                    calls.push(function (asyncCallback) {
                        var doc = allDocs.find(function findElement(element) {
                            return element.doc._id === _id4;
                        }).doc;
                        expect(doc).not.to.be.undefined;
                        expect(doc.testID).to.exist;
                        expect(doc.testID).not.to.be.empty;
                        expect(doc.testID).to.be.a('string');
                        expect(doc.idIndex).to.exist;
                        expect(doc.idIndex).not.to.be.empty;
                        expect(doc.idIndex).to.be.a('string');
                        var docIdIndex = docId + doc.idIndex;
                        expect(docIdIndex).to.be.equal(docId + "4");
                        expect(doc.testID).to.be.equal(docIdIndex);
                        asyncCallback(null, true);
                    });

                    async.series(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });

                });
            });
        });

    });

    describe('Cloudant BaseDAL.select', function () {
        it('BaseDAL.select Above Number success', function (done) {

            var calls = [];

            var queryGreaterThan3 =
                {
                    "params": [{
                        "key": "num",
                        "value": 3,
                        "operand": ">"
                    }
                    ]
                };

            var queryGreaterThan5 =
                {
                    "params": [{
                        "key": "num",
                        "value": 5,
                        "operand": ">"
                    }
                    ]
                };

            var queryGreaterThan7 =
                {
                    "params": [{
                        "key": "num",
                        "value": 7,
                        "operand": ">"
                    }
                    ]
                };

            dal.createDB(function (err) {

                expect(err).to.be.null;

                var insertedDocs = [];
                insertedDocs.push({num: 4});
                insertedDocs.push({num: 6});

                dal.insertBulk(insertedDocs, function (err, result) {

                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterThan3, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(2);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterThan5, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs[0].num).to.be.equal(6);

                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterThan7, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).to.be.empty;
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });

                });

            });
        });

        it('BaseDAL.select Above or Equal to Number success', function (done) {

            var calls = [];

            var queryGreaterOrEqualTo3 =
                {
                    "params": [{
                        "key": "num",
                        "value": 3,
                        "operand": ">="
                    }
                    ]
                };

            var queryGreaterOrEqualTo4 =
                {
                    "params": [{
                        "key": "num",
                        "value": 4,
                        "operand": ">="
                    }
                    ]
                };

            var queryGreaterOrEqualTo5 =
                {
                    "params": [{
                        "key": "num",
                        "value": 5,
                        "operand": ">="
                    }
                    ]
                };

            var queryGreaterOrEqualTo6 =
                {
                    "params": [{
                        "key": "num",
                        "value": 6,
                        "operand": ">="
                    }
                    ]
                };

            var queryGreaterOrEqualTo7 =
                {
                    "params": [{
                        "key": "num",
                        "value": 7,
                        "operand": ">="
                    }
                    ]
                };


            dal.createDB(function (err) {
                expect(err).to.be.null;

                var insertedDocs = [];
                insertedDocs.push({num: 4});
                insertedDocs.push({num: 6});

                dal.insertBulk(insertedDocs, function (err, result) {

                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterOrEqualTo3, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(2);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterOrEqualTo4, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(2);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;

                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterOrEqualTo5, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterOrEqualTo6, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryGreaterOrEqualTo7, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).to.be.empty;
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });


                });

            });
        });

        it('BaseDAL.select Below Number success', function (done) {
            var calls = [];

            var querySmallerThan3 =
                {
                    "params": [{
                        "key": "num",
                        "value": 3,
                        "operand": "<"
                    }
                    ]
                };

            var querySmallerThan5 =
                {
                    "params": [{
                        "key": "num",
                        "value": 5,
                        "operand": "<"
                    }
                    ]
                };

            var querySmallerThan7 =
                {
                    "params": [{
                        "key": "num",
                        "value": 7,
                        "operand": "<"
                    }
                    ]
                };

            dal.createDB(function (err) {

                expect(err).to.be.null;

                var insertedDocs = [];
                insertedDocs.push({num: 4});
                insertedDocs.push({num: 6});

                dal.insertBulk(insertedDocs, function (err, result) {

                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerThan7, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(2);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerThan5, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs[0].num).to.be.equal(4);

                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerThan3, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).to.be.empty;
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });

                });

            });
        });

        it('BaseDAL.select Below or Equal to Number success', function (done) {
            var calls = [];

            var querySmallerOrEqualTo3 =
                {
                    "params": [{
                        "key": "num",
                        "value": 3,
                        "operand": "<="
                    }
                    ]
                };

            var querySmallerOrEqualTo4 =
                {
                    "params": [{
                        "key": "num",
                        "value": 4,
                        "operand": "<="
                    }
                    ]
                };

            var querySmallerOrEqualTo5 =
                {
                    "params": [{
                        "key": "num",
                        "value": 5,
                        "operand": "<="
                    }
                    ]
                };

            var querySmallerOrEqualTo6 =
                {
                    "params": [{
                        "key": "num",
                        "value": 6,
                        "operand": "<="
                    }
                    ]
                };

            var querySmallerOrEqualTo7 =
                {
                    "params": [{
                        "key": "num",
                        "value": 7,
                        "operand": "<="
                    }
                    ]
                };

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var insertedDocs = [];
                insertedDocs.push({num: 4});
                insertedDocs.push({num: 6});

                dal.insertBulk(insertedDocs, function (err, result) {

                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerOrEqualTo7, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(2);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerOrEqualTo6, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(2);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;

                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerOrEqualTo5, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerOrEqualTo4, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(querySmallerOrEqualTo3, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).to.be.empty;
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });


                });

            });
        });

        it('BaseDAL.select Equal to Number success', function (done) {

            var calls = [];

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var queryEqualTo4 =
                    {
                        "params": [{
                            "key": "num",
                            "value": 4,
                            "operand": "="
                        }
                        ]
                    };

                var queryEqualTo5 =
                    {
                        "params": [{
                            "key": "num",
                            "value": 5,
                            "operand": "="
                        }
                        ]
                    };

                var queryEqualTo6 =
                    {
                        "params": [{
                            "key": "num",
                            "value": 6,
                            "operand": "="
                        }
                        ]
                    };

                var insertedDocs = [];
                insertedDocs.push({num: 4});
                insertedDocs.push({num: 6});

                dal.insertBulk(insertedDocs, function (err, result) {

                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    calls.push(function (asyncCallback) {
                        dal.select(queryEqualTo4, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs.find(function findElement(element) {
                                return element.num === 4;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryEqualTo5, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.empty;
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryEqualTo6, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.equal(1);
                            expect(docs.find(function findElement(element) {
                                return element.num === 6;
                            })).not.to.be.undefined;
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });


                });

            });
        });

        it('BaseDAL.select Equal to String success', function (done) {

            var calls = [];

            var rndStr1 = new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz", length: 12});
            var rndStr2 = new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz", length: 12});
            var rndStr3 = new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz", length: 12});

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var queryEqualToString1 =
                    {
                        "params": [{
                            "key": "str",
                            "value": rndStr1,
                            "operand": "="
                        }
                        ]
                    };

                var queryEqualToString2 =
                    {
                        "params": [{
                            "key": "str",
                            "value": rndStr2,
                            "operand": "="
                        }
                        ]
                    };

                var queryEqualToString3 =
                    {
                        "params": [{
                            "key": "str",
                            "value": rndStr3,
                            "operand": "="
                        }
                        ]
                    };

                var insertedDocs = [];
                insertedDocs.push({str: rndStr1});
                insertedDocs.push({str: rndStr2});

                dal.insertBulk(insertedDocs, function (err, result) {

                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;

                    calls.push(function (asyncCallback) {
                        dal.select(queryEqualToString1, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.be.equal(1);
                            expect(rndStr1).to.be.equal(docs[0].str);
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryEqualToString2, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.be.a('array');
                            expect(docs).not.to.be.empty;
                            expect(docs.length).to.be.equal(1);
                            expect(rndStr2).to.be.equal(docs[0].str);
                            asyncCallback(null, true);
                        });
                    });

                    calls.push(function (asyncCallback) {
                        dal.select(queryEqualToString3, function (err, docs) {
                            expect(err).to.be.null;
                            expect(docs).to.exist;
                            expect(docs).to.be.a('array');
                            expect(docs).to.be.empty;
                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });

                });

            });
        });

    });

    describe('Cloudant BaseDAL.selectViewByKey', function () {

        it('BaseDAL.selectViewByKey design and view name exists', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);

                // Insert Entity
                dal.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    dal.selectViewByKey(undefined, docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults).to.be.empty;

                        done();
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey view name does not exist', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);

                // Insert Entity
                dal.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    dal.selectViewByKey(undefined, docId, "testIDView1", true, function (err, viewResults) {
                        expect(err).not.to.be.null;
                        expect(viewResults).to.be.null;

                        done();
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey design name does not exist', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);

                // Insert Entity
                dal.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    dal.selectViewByKey(undefined, docId + "1", "testIDView", true, function (err, viewResults) {
                        expect(err).not.to.be.null;
                        expect(viewResults).to.be.null;

                        done();
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey single key single entry', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey(docs[0].testID, docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(1);

                            var receivedDoc = viewResults[0];
                            expect(receivedDoc).not.to.be.null;
                            expect(receivedDoc.testID).to.exist;
                            expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey single key no entries', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    // Insert Entity
                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey(docs[0].testID + "asdf", docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults).to.be.empty;

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey single key multiple entries', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc1", testno: "2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    // Insert Entity
                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey(docs[0].testID, docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(2);

                            var calls = [];

                            calls.push(function (asyncCallback) {

                                var doc = docs.find(function findElement(element) {
                                    return element.testno === docs[0].testno;
                                });

                                expect(doc).not.to.be.undefined;

                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docs[0].testID);
                                expect(doc.testno).to.exist;
                                expect(doc.testno).not.to.be.empty;
                                expect(doc.testno).to.be.a('string');
                                expect(doc.testno).to.be.equal(docs[0].testno);

                                asyncCallback(null, true);
                            });

                            calls.push(function (asyncCallback) {

                                var doc = docs.find(function findElement(element) {
                                    return element.testno === docs[1].testno;
                                });

                                expect(doc).not.to.be.undefined;

                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docs[1].testID);
                                expect(doc.testno).to.exist;
                                expect(doc.testno).not.to.be.empty;
                                expect(doc.testno).to.be.a('string');
                                expect(doc.testno).to.be.equal(docs[1].testno);

                                asyncCallback(null, true);
                            });



                            async.parallel(calls, function (err, result) {
                                expect(err).to.be.null;
                                done();
                            });
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey array, single key single entry', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc2", testno: "2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey([docs[0].testID], docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(1);

                            var receivedDoc = viewResults[0];
                            expect(receivedDoc).not.to.be.null;
                            expect(receivedDoc.testID).to.exist;
                            expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey array, single key no entries', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    // Insert Entity
                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey([docs[0].testID + "asdf"], docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults).to.be.empty;

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey array, single key multiple entries', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc1", testno: "2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    // Insert Entity
                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey([docs[0].testID], docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(2);

                            var calls = [];

                            calls.push(function (asyncCallback) {

                                var doc = docs.find(function findElement(element) {
                                    return element.testno === docs[0].testno;
                                });

                                expect(doc).not.to.be.undefined;

                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docs[0].testID);
                                expect(doc.testno).to.exist;
                                expect(doc.testno).not.to.be.empty;
                                expect(doc.testno).to.be.a('string');
                                expect(doc.testno).to.be.equal(docs[0].testno);

                                asyncCallback(null, true);
                            });

                            calls.push(function (asyncCallback) {

                                var doc = docs.find(function findElement(element) {
                                    return element.testno === docs[1].testno;
                                });

                                expect(doc).not.to.be.undefined;

                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docs[1].testID);
                                expect(doc.testno).to.exist;
                                expect(doc.testno).not.to.be.empty;
                                expect(doc.testno).to.be.a('string');
                                expect(doc.testno).to.be.equal(docs[1].testno);

                                asyncCallback(null, true);
                            });



                            async.parallel(calls, function (err, result) {
                                expect(err).to.be.null;
                                done();
                            });
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey array, multiple keys single entry', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc2", testno: "2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey([docs[0].testID, "asdf"], docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(1);

                            var receivedDoc = viewResults[0];
                            expect(receivedDoc).not.to.be.null;
                            expect(receivedDoc.testID).to.exist;
                            expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey array, multiple keys no entries', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    // Insert Entity
                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey([docs[0].testID + "asdf", "asdf"], docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults).to.be.empty;

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey array, multiple keys multiple entries', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc2", testno: "2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    // Insert Entity
                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey([docs[0].testID, docs[1].testID], docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(2);

                            var calls = [];

                            calls.push(function (asyncCallback) {

                                var doc = docs.find(function findElement(element) {
                                    return element.testno === docs[0].testno;
                                });

                                expect(doc).not.to.be.undefined;

                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docs[0].testID);
                                expect(doc.testno).to.exist;
                                expect(doc.testno).not.to.be.empty;
                                expect(doc.testno).to.be.a('string');
                                expect(doc.testno).to.be.equal(docs[0].testno);

                                asyncCallback(null, true);
                            });

                            calls.push(function (asyncCallback) {

                                var doc = docs.find(function findElement(element) {
                                    return element.testno === docs[1].testno;
                                });

                                expect(doc).not.to.be.undefined;

                                expect(doc.testID).to.exist;
                                expect(doc.testID).not.to.be.empty;
                                expect(doc.testID).to.be.a('string');
                                expect(doc.testID).to.be.equal(docs[1].testID);
                                expect(doc.testno).to.exist;
                                expect(doc.testno).not.to.be.empty;
                                expect(doc.testno).to.be.a('string');
                                expect(doc.testno).to.be.equal(docs[1].testno);

                                asyncCallback(null, true);
                            });



                            async.parallel(calls, function (err, result) {
                                expect(err).to.be.null;
                                done();
                            });
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey include docs', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey(docs[0].testID, docId, "testIDView", true, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(1);

                            var receivedDoc = viewResults[0];
                            expect(receivedDoc).not.to.be.null;
                            expect(receivedDoc.testID).to.exist;
                            expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL.selectViewByKey dont include doc', function (done) {

            dal.createDB(function (err) {
                expect(err).to.be.null;

                var view = testTools.getViewWithDocID(docId);
                var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

                dal.insertBulk(docs, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.a('array');
                    expect(result).not.to.be.empty;
                    expect(result.length).to.be.equal(docs.length);

                    dal.insert(view, function (err, result) {
                        expect(err).to.be.null;
                        expect(result.id).to.exist;
                        expect(result.id).not.to.be.empty;
                        expect(result.id).to.be.a('string');

                        dal.selectViewByKey(docs[0].testID, docId, "testIDView", false, function (err, viewResults) {
                            expect(err).to.be.null;
                            expect(viewResults).not.to.be.null;
                            expect(viewResults).to.be.a('array');
                            expect(viewResults.length).to.be.equal(1);

                            var receivedDoc = viewResults[0];
                            expect(receivedDoc.id).not.to.be.null;
                            expect(receivedDoc.key).not.to.be.null;
                            expect(receivedDoc.value).not.to.be.null;
                            expect(receivedDoc.key).to.be.equal(docs[0].testID);

                            done();
                        });
                    });
                });
            });
        });
    });

    // describe('Cloudant BaseDAL.uploadFile', function () {
    //
    //     it('BaseDAL.uploadFile success', function (done) {
    //         expect(true).to.be.false;
    //         done();
    //     });
    // });
    //
    // describe('Cloudant BaseDAL.downloadFile', function () {
    //
    //     it('BaseDAL.downloadFile success', function (done) {
    //         expect(true).to.be.false;
    //         done();
    //     });
    // });
});
