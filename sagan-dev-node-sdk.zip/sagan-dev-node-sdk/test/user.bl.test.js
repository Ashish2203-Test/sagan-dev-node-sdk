/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var dbmgr = require('../cloudant-dal/db-manager.js');
var userBL = require('../business-logic/user.bl.js');
var async = require('async');
var testTools = require('./testTools.js');
var path = require('path');
var dataFilePath = path.join(__dirname, "bl", "user.json");
var iotfClient = require('../iotfClient.js');

describe('User BL', function () {
    var docId = "";

    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        //testTools.disableLogs();

        dbmgr.create(userBL._name, function (err) {
            expect(err).to.be.null;
            done();
        });

    });


    afterEach(function (done) {
        dbmgr.delete(userBL._name, function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;
            done();
        });
    });

    after(function () {
    });

    var loadTestByName = function (testName, callback) {
        dbmgr.loadFileData(dataFilePath, testName, function (err, results) {
            expect(err).to.be.null;
            callback(err, results)
        });
    };


    describe('user.hashPasswordWithSalt', function () {

        it('user.hashPasswordWithSalt normal', function (done) {

            var password = "password";
            var hash = "hash";

            var hashedPassword = userBL.hashPasswordWithSalt(password, hash);
            console.log("======: " + hashedPassword);
            expect(hashedPassword).not.to.be.equal(password);

            done();
        });

        it('user.hashPasswordWithSalt password empty', function (done) {

            var password = "";
            var hash = "hash";

            var hashedPassword = userBL.hashPasswordWithSalt(password, hash);
            console.log("======: " + hashedPassword);
            expect(hashedPassword).not.to.be.equal(password);

            done();
        });

        it('user.hashPasswordWithSalt password undefined', function (done) {

            var password;
            var hash = "hash";

            var hashedPassword = userBL.hashPasswordWithSalt(password, hash);
            console.log("======: " + hashedPassword);
            expect(hashedPassword).not.to.be.equal(password);

            done();
        });


        it('user.hashPasswordWithSalt hash empty', function (done) {

            var password = "password";
            var hash = "";

            var hashedPassword = userBL.hashPasswordWithSalt(password, hash);
            console.log("======: " + hashedPassword);
            expect(hashedPassword).not.to.be.equal(password);

            done();
        });

        it('user.hashPasswordWithSalt hash undefined', function (done) {

            var password = "password";
            var hash;

            var hashedPassword = userBL.hashPasswordWithSalt(password, hash);
            console.log("======: " + hashedPassword);
            expect(hashedPassword).not.to.be.equal(password);

            done();
        });
    });

    describe('user.insert', function () {

        it('user.insert doc', function (done) {
            var docToInsert = require(dataFilePath).insertDoc[0].data[0];

            userBL.insert(docToInsert, function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                userBL.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    docToInsert.password = userBL.hashPasswordWithSalt(docToInsert.password, docToInsert.username);

                    expect(getDoc.username).to.be.equal(docToInsert.username);
                    expect(getDoc.password).to.be.equal(docToInsert.password);
                    expect(getDoc.fullname).to.be.equal(docToInsert.fullname);
                    expect(getDoc.firstname).to.be.equal(docToInsert.firstname);
                    expect(getDoc.lastname).to.be.equal(docToInsert.lastname);
                    expect(getDoc.tags).to.be.equal(docToInsert.tags);
                    expect(getDoc.email).to.be.equal(docToInsert.email);
                    expect(getDoc.address).to.be.equal(docToInsert.address);
                    expect(getDoc.iotresult).to.be.equal(docToInsert.iotresult);
                    expect(getDoc.managers).to.be.equal(docToInsert.managers);
                    expect(getDoc.accessLevel).to.be.equal(docToInsert.accessLevel);

                    done();
                });
            });
        });

        it('user.insert with access level', function (done) {
            var docToInsert = require(dataFilePath).insertDocWithAccessLevel[0].data[0];

            userBL.insert(docToInsert, function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                userBL.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    expect(getDoc.accessLevel).to.be.equal(docToInsert.accessLevel);

                    done();
                });
            });
        });

        it('user.insert with access level', function (done) {
            var docToInsert = require(dataFilePath).insertDocWithoutAccessLevel[0].data[0];

            userBL.insert(docToInsert, function (err, result) {
                expect(err).to.be.null;
                expect(result).not.to.be.null;

                userBL.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    expect(getDoc.accessLevel).to.be.equal(100);

                    done();
                });
            });
        });
    });

    describe('user.getByUsername', function () {
        it('user.getByUsername single doc', function (done) {
            var testName = "getByUsernameSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];

                userBL.getByID(insertedDoc.id, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    userBL.getByUsername(getResult.username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });

        it('user.getByUsername multiple doc', function (done) {
            var testName = "getByUsernameMultipleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var insertedDoc = result[0];

                userBL.getByID(insertedDoc.id, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    userBL.getByUsername(getResult.username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });

        it('user.getByUsername non existing doc', function (done) {
            var testName = "getByUsernameNonExistingDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getByUsername("asdf", function (err, getUser) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Got too many users or none')
                    expect(getUser).to.be.null;

                    done();
                });
            });
        });
    });

    describe('user.checkUserCredentialsFull', function () {

        it('user.checkUserCredentialsFull single user', function (done) {
            var testName = "checkUserCredentialsFullSingleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentialsFull(docToInsert.username, docToInsert.password, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    userBL.getByUsername(getResult.username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });

        it('user.checkUserCredentialsFull single user wrong username', function (done) {
            var testName = "checkUserCredentialsFullSingleUserWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentialsFull(docToInsert.username + "asdf", docToInsert.password, function (err, getResult) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('user/pass not found');
                    expect(getResult).to.be.null;

                    done();
                });
            });
        });


        it('user.checkUserCredentialsFull single user wrong password', function (done) {
            var testName = "checkUserCredentialsFullSingleUserWrongPassword";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentialsFull(docToInsert.username, docToInsert.password + "asdf", function (err, getResult) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('user/pass not found');
                    expect(getResult).to.be.null;

                    done();
                });
            });
        });

        it('user.checkUserCredentialsFull multiple users', function (done) {
            var testName = "checkUserCredentialsFullMultipleUsers";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentialsFull(docToInsert.username, docToInsert.password, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;

                    userBL.getByUsername(getResult.username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser).to.be.deep.equal(getResult);

                        done();
                    });
                });
            });
        });


        it('user.checkUserCredentialsFull single user missing username', function (done) {
            var testName = "checkUserCredentialsFullMissingUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentialsFull(undefined, docToInsert.password, function (err, getResult) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('user/pass not found');
                    expect(getResult).to.be.null;

                    done();
                });
            });
        });

        it('user.checkUserCredentialsFull single user missing password', function (done) {
            var testName = "checkUserCredentialsFullSingleUserMissingPassword";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentialsFull(docToInsert.username, undefined, function (err, getResult) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('user/pass not found');
                    expect(getResult).to.be.null;

                    done();
                });
            });
        });
    });

    describe('user.checkUserCredentials ', function () {

        it('user.checkUserCredentials single user', function (done) {
            var testName = "checkUserCredentialsSingleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentials(docToInsert.username, docToInsert.password, function (err, isValid) {
                    expect(err).to.be.null;
                    expect(isValid).to.be.true;

                    done();
                });
            });
        });

        it('user.checkUserCredentials single user wrong username', function (done) {
            var testName = "checkUserCredentialsSingleUserWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentials(docToInsert.username + "asdf", docToInsert.password, function (err, isValid) {
                    expect(err).not.to.be.null;
                    expect(isValid).to.be.null;

                    done();
                });
            });
        });


        it('user.checkUserCredentials single user wrong password', function (done) {
            var testName = "checkUserCredentialsSingleUserWrongPassword";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentials(docToInsert.username, docToInsert.password + "asdf", function (err, isValid) {
                    expect(err).not.to.be.null;
                    expect(isValid).to.be.null;

                    done();
                });
            });
        });

        it('user.checkUserCredentials multiple users', function (done) {
            var testName = "checkUserCredentialsMultipleUsers";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentials(docToInsert.username, docToInsert.password, function (err, isValid) {
                    expect(err).to.be.null;
                    expect(isValid).to.be.true;

                    done();
                });
            });
        });


        it('user.checkUserCredentials single user missing username', function (done) {
            var testName = "checkUserCredentialsMissingUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentials(undefined, docToInsert.password, function (err, isValid) {
                    expect(err).not.to.be.null;
                    expect(isValid).to.be.null;

                    done();
                });
            });
        });

        it('user.checkUserCredentials single user missing password', function (done) {
            var testName = "checkUserCredentialsSingleUserMissingPassword";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.checkUserCredentials(docToInsert.username, undefined, function (err, isValid) {
                    expect(err).not.to.be.null;
                    expect(isValid).to.be.null;

                    done();
                });
            });
        });
    });

    describe('user.getAllSensorsAndUsers ', function () {

        it('user.getAllSensorsAndUsers single user', function (done) {
            var testName = "getAllSensorsAndUsersSingleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllSensorsAndUsers(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getAllSensorsAndUsers multiple users', function (done) {
            var testName = "getAllSensorsAndUsersMultipleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllSensorsAndUsers(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('2');

                    done();
                });
            });
        });

        it('user.getAllSensorsAndUsers multiple users only one with sensors', function (done) {
            var testName = "getAllSensorsAndUsersMultipleUserOnlyOne";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllSensorsAndUsers(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getAllSensorsAndUsers multiple users only no one with sensors', function (done) {
            var testName = "getAllSensorsAndUsersMultipleUserNone";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllSensorsAndUsers(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).to.be.empty;

                    done();
                });
            });
        });

        it('user.getAllSensorsAndUsers more than 40', function (done) {
            var testName = "getAllSensorsAndUsersMoreThan40";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllSensorsAndUsers(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('40');

                    done();
                });
            });
        });
    });

    describe('user.getMyUsers', function () {

        it('user.getMyUsers single user single manager', function (done) {
            var testName = "getMyUsersSingleUserSingleManager";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyUsers(manager, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getMyUsers single user multiple managers', function (done) {
            var testName = "getMyUsersSingleUserMultipleManagers";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyUsers(manager, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getMyUsers multiple users single manager', function (done) {
            var testName = "getMyUsersMultipleUserSingleManager";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyUsers(manager, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('2');

                    done();
                });
            });
        });

        it('user.getMyUsers multiple users only one', function (done) {
            var testName = "getMyUsersMultipleUserOnlyOne";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyUsers(manager, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getMyUsers multiple users none', function (done) {
            var testName = "getMyUsersMultipleUserNone";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyUsers(manager, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).to.be.empty;

                    done();
                });
            });
        });

        it('user.getMyUsers manager name undefined', function (done) {
            var testName = "getMyUsersManagerNameUndefined";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyUsers(undefined, function (err, users) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Specify username');
                    expect(users).to.be.a('array');
                    expect(users).to.be.empty;

                    done();
                });
            });
        });
    });

    describe('user.getMyImmediateSubordinates', function () {

        it('user.getMyImmediateSubordinates single user single manager', function (done) {
            var testName = "getMyImmediateSubordinatesSingleUserSingleManager";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, true, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates single user multiple managers', function (done) {
            var testName = "getMyImmediateSubordinatesSingleUserMultipleManagers";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, true, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates multiple users single manager', function (done) {
            var testName = "getMyImmediateSubordinatesMultipleUserSingleManager";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, true, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('2');

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates multiple users only one', function (done) {
            var testName = "getMyImmediateSubordinatesMultipleUserOnlyOne";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, true, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates multiple users none', function (done) {
            var testName = "getMyImmediateSubordinatesMultipleUserNone";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, true, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).to.be.empty;

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates manager name undefined', function (done) {
            var testName = "getMyImmediateSubordinatesManagerNameUndefined";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(undefined, true, function (err, users) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Specify username');
                    expect(users).to.be.a('array');
                    expect(users).to.be.empty;

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates with docs', function (done) {
            var testName = "getMyImmediateSubordinatesWithDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, true, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');
                    expect(users[0].username).not.to.be.null;

                    done();
                });
            });
        });

        it('user.getMyImmediateSubordinates Without Docs', function (done) {
            var testName = "getMyImmediateSubordinatesWithoutDocs";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var manager = "manager";

                userBL.getMyImmediateSubordinates(manager, false, function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');
                    expect(users[0].username).to.be.undefined;

                    done();
                });
            });
        });
    });

    describe('user.updateAttributeByUsername', function () {

        it('user.updateAttributeByUsername existing field', function (done) {
            var testName = "updateAttributeByUsernameExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateAttributeByUsername(username, "fullname", "name", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.fullname).to.be.equal("name");

                        done();
                    });
                });
            });
        });

        it('user.updateAttributeByUsername existing field same value', function (done) {
            var testName = "updateAttributeByUsernameExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateAttributeByUsername(username, "fullname", "fullname", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.fullname).to.be.equal("fullname");

                        done();
                    });
                });
            });
        });

        it('user.updateAttributeByUsername adding field', function (done) {
            var testName = "updateAttributeByUsernameAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateAttributeByUsername(username, "fullname", "fullname", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.fullname).to.be.equal("fullname");

                        done();
                    });
                });
            });
        });

        it('user.updateAttributeByUsername removing field', function (done) {
            var testName = "updateAttributeByUsernameRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateAttributeByUsername(username, "fullname", undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.fullname).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('user.updateAttributeByUsername wrong username', function (done) {
            var testName = "updateAttributeByUsernameWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateAttributeByUsername(username + "asdf", "fullname", "name", function (err, result) {
                    expect(err).not.to.be.null;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.fullname).to.be.equal("fullname");

                        done();
                    });
                });
            });
        });
    });

    describe('user.updateUserAvailability', function () {

        it('user.updateUserAvailability existing field', function (done) {
            var testName = "updateUserAvailabilityExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAvailability(username, false, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isavailable).to.be.false;

                        done();
                    });
                });
            });
        });

        it('user.updateUserAvailability existing field same value', function (done) {
            var testName = "updateUserAvailabilityExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAvailability(username, true, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isavailable).to.be.true;

                        done();
                    });
                });
            });
        });

        it('user.updateUserAvailability adding field', function (done) {
            var testName = "updateUserAvailabilityAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAvailability(username, true, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isavailable).to.be.true;

                        done();
                    });
                });
            });
        });

        it('user.updateUserAvailability removing field', function (done) {
            var testName = "updateUserAvailabilityRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAvailability(username, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isavailable).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('user.updateUserAvailability wrong username', function (done) {
            var testName = "updateUserAvailabilityWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAvailability(username + "asdf", false, function (err, result) {
                    expect(err).not.to.be.null;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.isavailable).to.be.true;

                        done();
                    });
                });
            });
        });
    });

    describe('user.updateUserAccessLevel', function () {

        it('user.updateUserAccessLevel existing field', function (done) {
            var testName = "updateUserAccessLevelExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAccessLevel(username, 60, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.accessLevel).to.be.equal(60);

                        done();
                    });
                });
            });
        });

        it('user.updateUserAccessLevel existing field same value', function (done) {
            var testName = "updateUserAccessLevelExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAccessLevel(username, 50, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.accessLevel).to.be.equal(50);

                        done();
                    });
                });
            });
        });

        it('user.updateUserAccessLevel adding field', function (done) {
            var testName = "updateUserAccessLevelAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAccessLevel(username, 50, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.accessLevel).to.be.equal(50);

                        done();
                    });
                });
            });
        });

        it('user.updateUserAccessLevel removing field', function (done) {
            var testName = "updateUserAccessLevelRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAccessLevel(username, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.accessLevel).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('user.updateUserAccessLevel wrong username', function (done) {
            var testName = "updateUserAccessLevelWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserAccessLevel(username + "asdf", 60, function (err, result) {
                    expect(err).not.to.be.null;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.accessLevel).to.be.equal(50);

                        done();
                    });
                });
            });
        });
    });

    describe('user.updateUserDeviceID', function () {

        it('user.updateUserDeviceID existing field', function (done) {
            var testName = "updateUserDeviceIDExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserDeviceID(username, "0987654321", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.deviceID).to.be.equal("0987654321");

                        done();
                    });
                });
            });
        });

        it('user.updateUserDeviceID existing field same value', function (done) {
            var testName = "updateUserDeviceIDExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserDeviceID(username, "1234567890", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.deviceID).to.be.equal("1234567890");

                        done();
                    });
                });
            });
        });

        it('user.updateUserDeviceID adding field', function (done) {
            var testName = "updateUserDeviceIDAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserDeviceID(username, "1234567890", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.deviceID).to.be.equal("1234567890");

                        done();
                    });
                });
            });
        });

        it('user.updateUserDeviceID removing field', function (done) {
            var testName = "updateUserDeviceIDRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserDeviceID(username, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.deviceID).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('user.updateUserDeviceID wrong username', function (done) {
            var testName = "updateUserDeviceIDWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserDeviceID(username + "asdf", "0987654321", function (err, result) {
                    expect(err).not.to.be.null;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.deviceID).to.be.equal("1234567890");

                        done();
                    });
                });
            });
        });
    });

    describe('user.updateUserKeepAliveTimestamp', function () {

        it('user.updateUserKeepAliveTimestamp existing field', function (done) {
            var testName = "updateUserKeepAliveTimestampExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserKeepAliveTimestamp(username, "2017-12-10T07:19:20.070Z", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.lastActivityTimestamp).to.be.equal("2017-12-10T07:19:20.070Z");

                        done();
                    });
                });
            });
        });

        it('user.updateUserKeepAliveTimestamp existing field same value', function (done) {
            var testName = "updateUserKeepAliveTimestampExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserKeepAliveTimestamp(username, "2016-12-10T07:19:20.070Z", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.lastActivityTimestamp).to.be.equal("2016-12-10T07:19:20.070Z");

                        done();
                    });
                });
            });
        });

        it('user.updateUserKeepAliveTimestamp adding field', function (done) {
            var testName = "updateUserKeepAliveTimestampAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserKeepAliveTimestamp(username, "2016-12-10T07:19:20.070Z", function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.lastActivityTimestamp).to.be.equal("2016-12-10T07:19:20.070Z");

                        done();
                    });
                });
            });
        });

        it('user.updateUserKeepAliveTimestamp removing field', function (done) {
            var testName = "updateUserKeepAliveTimestampRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserKeepAliveTimestamp(username, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.lastActivityTimestamp).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('user.updateUserKeepAliveTimestamp wrong username', function (done) {
            var testName = "updateUserKeepAliveTimestampWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];
                var username = "username";

                userBL.updateUserKeepAliveTimestamp(username + "asdf", "2017-12-10T07:19:20.070Z", function (err, result) {
                    expect(err).not.to.be.null;

                    userBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.lastActivityTimestamp).to.be.equal("2016-12-10T07:19:20.070Z");

                        done();
                    });
                });
            });
        });
    });

    describe('user.getAllUserProfiles ', function () {

        it('user.getAllUserProfiles single user', function (done) {
            var testName = "getAllUserProfilesSingleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllUserProfiles(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getAllUserProfiles multiple users', function (done) {
            var testName = "getAllUserProfilesMultipleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllUserProfiles(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('2');

                    done();
                });
            });
        });

        it('user.getAllUserProfiles multiple users only one with profile', function (done) {
            var testName = "getAllUserProfilesMultipleUserOnlyOne";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllUserProfiles(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).not.to.be.empty;
                    expect(users.length).not.to.be.equal('1');

                    done();
                });
            });
        });

        it('user.getAllUserProfiles multiple users only no one with profiles', function (done) {
            var testName = "getAllUserProfilesMultipleUserNone";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                userBL.getAllUserProfiles(function (err, users) {
                    expect(err).to.be.null;
                    expect(users).to.be.a('array');
                    expect(users).to.be.empty;

                    done();
                });
            });
        });
    });

    describe('user.getDevicesToPush', function () {
        it('user.getDevicesToPush single user', function (done) {
            var testName = "getDevicesToPushSingleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "username";

                userBL.getDevicesToPush(username, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;
                    expect(getResult).to.be.a('array');
                    expect(getResult).not.to.be.empty;

                    userBL.getByUsername(username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser.deviceID).to.be.equal(getResult[0]);

                        done();
                    });
                });
            });
        });

        it('user.getDevicesToPush multiple users', function (done) {
            var testName = "getDevicesToPushMultipleUser";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "username1";

                userBL.getDevicesToPush(username, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;
                    expect(getResult).to.be.a('array');
                    expect(getResult).not.to.be.empty;

                    userBL.getByUsername(username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getUser.deviceID).to.be.equal(getResult[0]);

                        done();
                    });
                });
            });
        });

        it('user.getDevicesToPush no device id', function (done) {
            var testName = "getDevicesToPushNoDeviceID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "username1";

                userBL.getDevicesToPush(username, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;
                    expect(getResult).to.be.a('array');
                    expect(getResult).not.to.be.empty;

                    userBL.getByUsername(username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getResult[0]).to.be.equal(undefined);

                        done();
                    });
                });
            });
        });

        it('user.getDevicesToPush wrong username', function (done) {
            var testName = "getDevicesToPushWrongUsername";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "username";

                userBL.getDevicesToPush(username, function (err, getResult) {
                    expect(err).not.to.be.null;
                    expect(getResult).not.to.be.null;
                    expect(getResult).to.be.a('array');
                    expect(getResult).to.be.empty;

                    done();
                });
            });
        });

        it('user.getDevicesToPush username undefined', function (done) {
            var testName = "getDevicesToPushUsernameUndefined";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var username = "username1";

                userBL.getDevicesToPush(username, function (err, getResult) {
                    expect(err).to.be.null;
                    expect(getResult).not.to.be.null;
                    expect(getResult).to.be.a('array');
                    expect(getResult).not.to.be.empty;

                    userBL.getByUsername(username, function (err, getUser) {
                        expect(err).to.be.null;
                        expect(getUser).not.to.be.null;
                        expect(getResult[0]).to.be.equal(undefined);

                        done();
                    });
                });
            });
        });
    });

    describe('user.addUser', function () {
        it('user.addUser single user', function (done) {
            var testName = "addUserAlreadyExists";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;
                expect(result).not.to.be.empty;

                var docToInsert = require(dataFilePath)[testName][0].data[0];

                userBL.addUser(docToInsert, function (err, iotResult) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('user already found in database!');
                    expect(iotResult).to.be.null;

                    done();
                });
            });
        });

        it('user.addUser invalid password', function (done) {
            var testName = "addUserInvalidPassword";
            var docToInsert = require(dataFilePath)[testName][0].data[0];

            // Mocking functions:
            var oldFunc = userBL.isPasswordValid;
            userBL.isPasswordValid = function (pass) {
                return false
            };

            userBL.addUser(docToInsert, function (err, iotResult) {
                userBL.isPasswordValid = oldFunc;
                expect(err).not.to.be.null;
                expect(err).to.be.equal('password does not meet the minimum requirements.');
                expect(iotResult).to.be.null;

                done();
            });
        });

        it('user.addUser error in IoT Platform', function (done) {
            var testName = "addUserErrorInIoTP";
            var docToInsert = require(dataFilePath)[testName][0].data[0];
            var iotpErr = 'error';

            // Mocking functions:
            var oldFunc = iotfClient.createDevice;
            iotfClient.createDevice = function (post_data, callback) {
                callback(iotpErr, null);
            };

            userBL.addUser(docToInsert, function (err, iotResult) {
                iotfClient.createDevice = oldFunc;
                expect(err).not.to.be.null;
                expect(err).to.be.equal('IOTF call failed with (' + iotpErr + ')');
                expect(iotResult).to.be.null;

                done();
            });
        });

        it('user.addUser message in IoT Platform response', function (done) {
            var testName = "addUserMessageInIoTP";
            var docToInsert = require(dataFilePath)[testName][0].data[0];
            var iotpMessage = 'message';

            // Mocking functions:
            var oldFunc = iotfClient.createDevice;
            iotfClient.createDevice = function (post_data, callback) {
                callback(null, {"message": iotpMessage});
            };

            userBL.addUser(docToInsert, function (err, iotResult) {
                iotfClient.createDevice = oldFunc;
                expect(err).not.to.be.null;
                expect(err).to.be.equal('user (' + iotpMessage + ')');
                expect(iotResult).to.be.null;

                done();
            });
        });

        it('user.addUser adding the user', function (done) {
            var testName = "addUserAddingUser";
            var docToInsert = require(dataFilePath)[testName][0].data[0];
            var IoTPResult = "iotresult";

            // Mocking functions:
            var oldFunc = iotfClient.createDevice;
            iotfClient.createDevice = function (post_data, callback) {
                callback(null, IoTPResult);
            };

            userBL.addUser(docToInsert, function (err, iotResult) {
                iotfClient.createDevice = oldFunc;
                expect(err).to.be.null;
                expect(iotResult).to.be.equal(IoTPResult);

                userBL.getByUsername(docToInsert.username, function (err, insertedUser) {
                    expect(err).to.be.null;
                    expect(insertedUser).not.to.be.null;
                    expect(insertedUser).not.to.be.empty;
                    expect(insertedUser.username).to.be.equal(docToInsert.username);
                    expect(insertedUser.iotresult).to.be.equal(IoTPResult);
                    expect(insertedUser.accessLevel).to.be.equal(10);

                    done();
                });
            });
        });

        it('user.addUser user is undefined', function (done) {
            var testName = "addUserUserIsUndefined";

            userBL.addUser(undefined, function (err, iotResult) {
                expect(err).not.to.be.null;
                expect(err).to.be.equal("User is undefined");
                expect(iotResult).to.be.null;

                done();
            });
        });
    });
});

