/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var config = require('../config.js');
var wfconfig = config.loadRootConfigFile();
var credentials = require('../credentials.js');
var cloudantCred = credentials.getCredentialsByServiceName('cloudantNoSQLDB');

if (!cloudantCred) {
    throw new Error("Missing Cloudant credentials");
}

var cloudant = require('cloudant');
var util = require('../util.js');
var cloudantDB = cloudant({url: cloudantCred.url, plugin:'retry', retryAttempts:10});

var getDB = function(dbName) {
    var newdb = cloudantDB.db.use(dbName);
    return newdb;
};

function createDB(dbName) {
    var self = this;
    self._dbName = wfconfig.env.WF_DB_NAME_PREFIX + dbName;
    initDB(self);
}

var initDB = function(dal) {
    dal._mydb = getDB(dal._dbName);
    dal.attachment = dal._mydb.attachment;
};

createDB.prototype.selectByID = function(id, callback) {
    var self = this;
    self._mydb.get(id, function(err, doc) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = selectByID, " +
                "dbname = " + self._dbName + ", " +
                "id = " + id + ", " +
                "doc = N/A, " +
                "Error = " + JSON.stringify(err));
            callback({"message" : "Error in selectByID", "reason" : err.message}, null);
        } else {
            callback(null, doc);
        }
    });
};

createDB.prototype.insert = function(newDoc, callback) {
    var self = this;

    // If the doc has a revision, it is already in the DB and will be conflicted
    if (newDoc._rev) {
        delete newDoc._id;
        delete newDoc._rev;
    }

    self._mydb.insert(newDoc, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = insert, " +
                "dbname = " + self._dbName + ", " +
                "id = " + newDoc._id + ", " +
                "doc = " + JSON.stringify(newDoc) + ", " +
                "error = " + err);
            callback("Error in insert", null);
        } else {
            callback(null, result);
        }
    });
};

createDB.prototype.insertBulk = function(bulkArray, callback) {
    var self = this;
    self._mydb.bulk({docs:bulkArray}, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = insertBulk, " +
                "dbname = " + self._dbName + ", " +
                "id = N/A, " +
                "doc = " + JSON.stringify(bulkArray) + ", " +
                "error = " + err);
            callback("Error in insertBulk", null);
        } else {
            callback(null, result);
        }
    });
};

createDB.prototype.update = function(newDoc, callback) {
    var self = this;
    self._mydb.insert(newDoc, newDoc._id, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = update, " +
                "dbname = " + self._dbName + ", " +
                "id = " + newDoc._id + ", " +
                "doc = " + JSON.stringify(newDoc) + ", " +
                "error = " + err);
            callback("Error in update", null);
        } else {
            callback(null, result);
        }
    });
};

createDB.prototype.list = function(callback) {
    var self = this;
    //self._mydb.list({
    //        include_docs: true
    // Filter out _design docs
    self.select(undefined,
        function(err, doc) {
            if (err) {
                console.log("ERROR " +
                    "module = basedal, " +
                    "function = list, " +
                    "dbname = " + self._dbName + ", " +
                    "error = " + err);
                callback("Error in list", null);
            } else {
                callback(null, doc);
            }
        });
};

createDB.prototype.listPaginated = function(limit, skip, callback) {
    var self = this;
    self._mydb.list({
        include_docs: true,
        limit: limit,
        skip: skip,
        descending: true
    }, function(err, doc) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = listPaginated, " +
                "dbname = " + self._dbName + ", " +
                "limit = " + limit + ", " +
                "skip = " + skip + ", " +
                "error = " + err);
            callback("Error in list", null);
        } else {
            doc.rows = doc.rows.filter(function(row) {
                console.log(JSON.stringify(row));
                return row.id.indexOf("_design") !== 0;
            });

            callback(null, doc);
        }
    });
};

createDB.prototype.delete = function(doc, callback) {
    var self = this;
    if (!(doc._id && doc._rev) && !(doc.id && doc.rev)) {
        console.log("ERROR " +
            "module = basedal, " +
            "function = delete, " +
            "dbname = " + self._dbName + ", " +
            "id = " + doc._id + ", " +
            "rev = " + doc._rev + ", " +
            "doc = " + JSON.stringify(doc) + ", " +
            "error = id or rev are missing");
            callback({"message" : "Error in delete", "reason" : "_id or _rev are missing"}, null);
    } else {
        self._mydb.destroy(doc._id || doc.id, doc._rev || doc.rev, function (err, response) {
            if (err) {
                console.log("ERROR " +
                    "module = basedal, " +
                    "function = delete, " +
                    "dbname = " + self._dbName + ", " +
                    "id = " + doc._id + ", " +
                    "doc = " + JSON.stringify(doc) + ", " +
                    "error = " + err);
                callback("Error in delete", null);
            } else {
                callback(null, response);
            }
        });
    }
};

createDB.prototype.deleteBulk = function(docs, callback) {
    var self = this;
    try {
        var deleteDocs = [];
        docs.forEach(function(row) {
            deleteDocs.push({
                _id: row._id || row.id,
                _rev: row._rev || row.rev,
                _deleted: true
            });
        });

        self._mydb.bulk({
            docs: deleteDocs
        }, function (err) {
            if (err) {
                console.log("ERROR " +
                    "module = basedal, " +
                    "function = deleteBulk, " +
                    "dbname = " + self._dbName + ", " +
                    "id = N/A, " +
                    "doc = " + JSON.stringify(docs) + ", " +
                    "error = " + JSON.stringify(err));
                callback(err, false);
            } else {
                callback(null, true);
            }
        });
    } catch (err) {
        console.log("ERROR " +
            "module = basedal, " +
            "function = deleteBulk, " +
            "dbname = " + self._dbName + ", " +
            "id = N/A, " +
            "doc = " + JSON.stringify(docs) + ", " +
            "error = " + JSON.stringify(err));

        callback(err, false);
    }
};

/////////////////////////////////////
/*
example:
var query =
{
	"params" : [ {
		"key" : "price",
		"value" : "50",
		"operand" : ">"
	}
],
"sort" : [
	{
		"key" : "timestamp",
		"value" : "desc"
	}],
	"page" : {
		"limit" : 1000,
		"skip" : 0
	}
};
*/
/////////////////////////////////////
createDB.prototype.select = function(query, callback) {
    var self = this;

    var select = {
        "selector": {
            "_id": {
                "$gt": 0,
                "$regex": "^(?!_design/)"
            }
        }
    };

    if (query) {
        var params = query.params;
        if (params) {
            params.forEach(function(param) {
                var op = parseOperand(param.operand);
                select.selector[param.key] = select.selector[param.key] || {};
                select.selector[param.key][op] = param.value;
            });
        }

        var sort = query.sort;
        if (sort) {
            select.sort = [];

            sort.forEach(function(order) {
                select.sort = select.sort || [];
                var newSort = {};
                newSort[order.key] = order.value;
                select.sort.push(newSort);
            });
        }

        var page = query.page;
        if (page) {
            select.limit = page.limit;
            select.skip = page.skip;
        }
    }
    self._mydb.find(select, function(err, doc) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = select, " +
                "dbname = " + self._dbName + ", " +
                "id = N/A " +
                "doc = " + JSON.stringify(select) + ", " +
                "error = " + err);
            callback("Error in select", null);
        } else {
            callback(null, doc.docs);
        }
    });
};

var parseOperand = function(operand) {
    switch (operand) {
        case "<":
            return "$lt";
        case "<=":
            return "$lte";
        case ">":
            return "$gt";
        case ">=":
            return "$gte";
        case "=":
            return "$eq";
        default:
            return operand;
    }
};

createDB.prototype.selectViewByKey = function(key, designName, viewName, includeDocs, callback) {
    var self = this;
    var viewOptions = {};

    if (key) {
        if (Array.isArray(key)) {
            viewOptions.keys = key;
        } else {
            viewOptions.keys = [key];
        }
    }

    viewOptions.include_docs = includeDocs;

    self._mydb.view(designName, viewName, viewOptions, function(err, docs) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = selectViewByKey, " +
                "dbname = " + self._dbName + ", " +
                "id = " + JSON.stringify(key) + ", " +
                "doc = N/A, " +
                "designName = " + designName + ", " +
                "viewName = " + viewName + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error in selectViewByKey", null);
        } else {
            results = docs.rows;
            newResults = [];

            if (includeDocs) {
                results.forEach(function(result) {
                    newResults.push(result.doc);
                });
            } else {
                newResults = results;
            }

            callback(null, newResults);
        }
    });
};

createDB.prototype.selectByAttribute = function(attributeName, attributeValue, callback) {
    var self = this;
    var query = {
        "selector": {
            "_id": {
                "$gt": 0,
                "$regex": "^(?!_design/)"
            }
        }
    };

    query.selector[attributeName] = attributeValue;

    self._mydb.find(query, function(err, doc) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = selectByAttribute, " +
                "dbname = " + self._dbName + ", " +
                "query = " + JSON.stringify(query) + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error in selectByAttribute", null);
        } else {
            callback(null, doc.docs);
        }
    });
};

createDB.prototype.uploadFile = function(doc, filename, data, mimetype, callback) {
    var self = this;
    console.log("uploadFile: " + doc._id);
    self._mydb.attachment.insert(doc._id, filename, data, mimetype, {
        rev: doc._rev
    }, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = uploadFile, " +
                "dbname = " + self._dbName + ", " +
                "id = " + doc._id + ", " +
                "doc = " + JSON.stringify(doc) + ", " +
                "filename = " + filename + ", " +
                "mimetype = " + mimetype + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error in uploadFile", null);
        } else {
            callback(null, result);
        }
    });
};

createDB.prototype.downloadFile = function(doc, filename, callback) {
    var self = this;
    self._mydb.attachment.get(doc._id, filename, {
        rev: doc._rev
    }, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = downloadFile, " +
                "dbname = " + self._dbName + ", " +
                "id = " + doc._id + ", " +
                "doc = " + JSON.stringify(doc) + ", " +
                "filename = " + filename + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error in downloadFile", null);
        } else {
            callback(null, result);
        }
    });
};

createDB.prototype.createDB = function(callback) {
    var self = this;
    cloudantDB.db.create(this._dbName, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = createDB, " +
                "dbname = " + self._dbName + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error in createDB", null);
        } else {
            initDB(self);
            callback(null, result);
        }
    });
};

createDB.prototype.deleteDB = function(callback) {
    var self = this;
    cloudantDB.db.destroy(this._dbName, function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = deleteDB, " +
                "dbname = " + self._dbName + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error in deleteDB", null);
        } else {
            console.log("INFO " +
                 "module = basedal, " +
                 "function = deleteDB, " +
                 "dbname = " + self._dbName + ", " +
                 "message = DB Deleted: " + self._dbName);
            callback(null, result);
        }
    });
};

createDB.prototype.doesDBExist = function(callback) {
    var self = this;
    cloudantDB.db.list(function(err, result) {
        if (err) {
            console.log("ERROR " +
                "module = basedal, " +
                "function = doesDBExist, " +
                "dbname = " + self._dbName + ", " +
                "Error = " + JSON.stringify(err));
            callback("Error retrieving DB list", null);
        } else {
            if (result.indexOf(self._dbName) === -1) {
                callback(null, false);
            } else {
                callback(null, true);
            }
        }
    });
};
module.exports = createDB;
