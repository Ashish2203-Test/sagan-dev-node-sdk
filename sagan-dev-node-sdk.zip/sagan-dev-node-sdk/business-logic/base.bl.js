/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var fs = require('fs');
var path = require('path');
var config = require('../config.js');
var wfconfig = config.loadRootConfigFile();

function createBL(dalName) {
    this._name = dalName;

    var dalpath = path.join(__dirname, "../cloudant-dal/", dalName + ".dal.js");

    this.dal = loadDal(dalpath);

    if (!this.dal) {

        if (wfconfig.dataaccess && wfconfig.dataaccess.path) {
            var otherDirs = wfconfig.dataaccess.path;

            for (index = 0; index < otherDirs.length && !this.dal; index++) {
                dalpath = path.join(path.resolve(otherDirs[index]), dalName + ".dal.js");
                this.dal = loadDal(dalpath);
            }
        }
    }

    if (this.dal) {
        console.log("INFO " +
            "module = basebl, " +
            "function = createBL, " +
            "dbname = " + this._name + ", " +
            "path = " + dalpath + ", " +
            "Message = Dal loaded");
    } else {
        console.log("ERROR " +
            "module = basebl, " +
            "function = createBL, " +
            "dbname = " + this._name + ", " +
            "path = " + dalpath + ", " +
            "Message = Fail to load dal");
    }
}

// Hadn't been tested
var loadDal = function (dalpath) {
    var isExists = fs.existsSync(dalpath);
    var dal;

    if (isExists) {
        dal = require(dalpath);
    }

    return (dal);
};

// Remove this function as soon as possible!
createBL.prototype.wrapResults = function (docs) {
    var results = {};

    if (!docs) {
        results.total = 0;
        results[this._name + 's'] = [];
    } else if (docs.rows) {
        results.total = docs.rows.length;
        results[this._name + 's'] = docs.rows;
    } else {
        results.total = docs.length;
        results[this._name + 's'] = docs;
    }
    return results;
};

createBL.prototype.getByID = function (id, callback) {
    this.dal.selectByID(id, callback);
};

createBL.prototype.getAllByAttribute = function (attributeName, attributeValue, callback) {
    if (attributeName === undefined) {
        callback("Must specify attribute name", null);
    } else if (attributeValue === undefined) {
        callback("Must specify attribute value", null);
    } else {
        this.dal.selectByAttribute(attributeName, attributeValue, callback);
    }
};

createBL.prototype.getAll = function (callback) {
    this.dal.list(callback);
};

createBL.prototype.getByView = function (key, designName, viewName, includeDocs, callback) {
    this.dal.selectViewByKey(key, designName, viewName, includeDocs, callback);
};

createBL.prototype.getAllPaginated = function (limit, skip, callback) {
    this.dal.listPaginated(limit, skip, callback);
};

createBL.prototype.insert = function (doc, callback) {
    this.dal.insert(doc, callback);
};

createBL.prototype.insertBulk = function (docs, callback) {
    this.dal.insertBulk(docs, callback);
};

// Hadn't been tested
createBL.prototype.uploadFile = function (doc, filename, data, mimetype, callback) {
    this.dal.uploadFile(doc, filename, data, mimetype, callback);
};

// Hadn't been tested
createBL.prototype.downloadFile = function (doc, filename, callback) {
    this.dal.downloadFile(doc, filename, callback);
};

createBL.prototype.update = function (doc, callback) {
    this.dal.update(doc, callback);
};

createBL.prototype.updateAttributeByID = function (id, attributeName, attributeValue, callback) {
    var self = this;
    if (!id) {
        callback("ID is undefined", null);
    } else if (!attributeName) {
        callback("Attribute Name is undefined", null);
    } else {
        self.getByID(id, function (err, doc) {
            if (err) {
                callback(err, null);
            } else {
                if (doc[attributeName] !== attributeValue) {
                    doc[attributeName] = attributeValue;

                    self.update(doc, function (err, response) {
                        if (err) {
                            callback(err, null);
                        } else {
                            callback(null, response);
                        }
                    });
                } else {
                    callback(null, false);
                }
            }
        });
    }
};

createBL.prototype.delete = function (doc, callback) {
    this.dal.delete(doc, callback);
};

createBL.prototype.deleteByID = function (id, callback) {
    var self = this;
    self.getByID(id, function (err, response) {
        if (err) {
            callback(err, null);
        } else {
            self.delete(response, callback);
        }
    });
};

createBL.prototype.deleteBulk = function (docs, callback) {
    this.dal.deleteBulk(docs, callback);
};

createBL.prototype.deleteAll = function (callback) {
    var self = this;
    self.getAll(function (err, result) {
        if (err) {
            callback(err, false);
        } else {
            self.dal.deleteBulk(result, callback);
        }
    });
};

createBL.prototype.countAll = function(callback) {
    this.dal.countAll(callback);
};


module.exports = createBL;
