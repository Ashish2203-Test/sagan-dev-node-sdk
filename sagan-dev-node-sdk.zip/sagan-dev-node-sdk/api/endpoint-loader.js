/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

let fs = require('fs');
let config = require('../config.js');
let path = require('path');
let wfconfig = config.loadRootConfigFile();
let resourcesPath = path.join(__dirname, "/endpoints/");

let endpointLoader = {};
endpointLoader.loadEndpoints = function (bagpipes, swagger) {

    processConfig(wfconfig);

    let endpoints = wfconfig.api.endpoints;
    if (endpoints) {
        endpoints.forEach(function (endpoint) {
            registerEndpoints(swagger, bagpipes, endpoint);

            console.log("INFO " +
                "module = endpoint-loader, " +
                "function = endpointLoader, " +
                "endpoint = " + endpoint.path + ", " +
                "message = Loading swagger models");
        });
    }

    // Loads after everything, because of the navigation tree
    registerEndpoints(swagger, bagpipes, wfconfig.api.wfendpoints);
};

let registerEndpoints = function (swagger, bagpipes, endpoint) {
    let dirExists = fs.existsSync(endpoint.path);
    if (!dirExists) {
        console.log("WARNING " +
            "module = endpoint-loader, " +
            "function = registerEndpoints, " +
            "message = Could not find path " + endpoint.path);
    } else {
        let toConsole = "Loading " + endpoint.path + ", APIs: ";
        console.log("INFO " +
            "module = endpoint-loader, " +
            "function = registerEndpoints, " +
            "endpoint = " + endpoint.path + ", " +
            "message = Start " + toConsole);

        // Add the API endpoints
        let files = fs.readdirSync(endpoint.path);

        let swaggerDoc = files.filter(function (file) {
            return (file.indexOf("swagger.json") === 0);
        })[0];

        if (!swaggerDoc) {
            console.log("WARNING " +
                "module = endpoint-loader, " +
                "function = registerEndpoints, " +
                "message = Could not find swagger doc in path" + endpoint.path);
        } else {
            addToSwagger(swagger, require(path.join(endpoint.path, swaggerDoc)), endpoint);
            addToBagPipes(bagpipes, endpoint.path);
        }
    }
};

let addToSwagger = function (swagger, swaggerDoc, endpoint) {
    // Need to override paths
    let paths = Object.keys(swaggerDoc.paths);
    let toConsole = "";

    paths.forEach(function (path) {

        if (endpoint.exclude.indexOf(path) === -1) {
            swagger.paths[path] = swaggerDoc.paths[path];

            toConsole += path + ", ";
        }
    });

    console.log("INFO " +
        "module = endpoint-loader, " +
        "function = registerEndpoints, " +
        "endpoint = " + endpoint.path + ", " +
        "message = " + toConsole.substr(0, toConsole.length - 2));

    let definitions = Object.keys(swaggerDoc.definitions);
    toConsole = "";

    definitions.forEach(function (definition) {
        swagger.definitions[definition] = swaggerDoc.definitions[definition];

        toConsole += definition + ", ";
    });

    console.log("INFO " +
        "module = endpoint-loader, " +
        "function = registerEndpoints, " +
        "endpoint = " + endpoint.path + ", " +
        "message = " + toConsole.substr(0, toConsole.length - 2));
};

let addToBagPipes = function (bagpipes, path) {
    // check if path already exists and add;
    if (bagpipes._router.controllersDirs.indexOf(path) === -1) {
        bagpipes._router.controllersDirs.push(path);
    }
};

// Transforming the wfconfig to a more convinient way
let processConfig = function (wfconfig) {

    wfconfig.api = wfconfig.api || {};
    wfconfig.api.wfendpoints = wfconfig.api.wfendpoints || {};
    wfconfig.api.wfendpoints.path = resourcesPath;

    if (wfconfig.api.endpoints) {
        wfconfig.api.endpoints.forEach(function (endpoint) {
            endpoint.path = path.resolve(config.rootDir, path.resolve(endpoint.path));
        });
    }
};

module.exports = endpointLoader;
