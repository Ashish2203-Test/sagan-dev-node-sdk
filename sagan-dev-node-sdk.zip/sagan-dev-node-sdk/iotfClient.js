/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var ibmiotf = require("ibmiotf");
var credentials = require('./credentials.js');
var util = require('./util.js');
var iotfClient = {};
var iotFoundationCredentials = credentials.getCredentialsByServiceName('iotf-service');
var path = require('path');

var messages = require( './messages.js');
var nodeuuid = require('node-uuid');

var appClient;
var connected;

function initIOTClient() {
    //	set IoT foundation credentials
    var organization = iotFoundationCredentials.org;
    var appId = util.randomIotCredentialsIdentifier();

    /* - not working for multiple instances
    // Unique ID for the application
	if (process && process.env && process.env.VCAP_APPLICATION) {
        //Guid is the max chars for appID
		appId = JSON.parse(process.env.VCAP_APPLICATION).application_id.substring(0, 10) + "iotf-client";
	}
*/
    var apiKey = iotFoundationCredentials.apiKey;
    var apiToken = iotFoundationCredentials.apiToken;
    var appDomain = iotFoundationCredentials.mqtt_host.substring(iotFoundationCredentials.mqtt_host.indexOf(".messaging.") + 11);

    //	connect to IoT foundation
    var config = {
        "org": organization,
        "id": appId,
        "auth-key": apiKey,
        "auth-token": apiToken,
        "domain": appDomain
    };


    appClient = new ibmiotf.IotfApplication(config);

    appClient.connect();

    appClient.on("connect", function() {
        console.log("iotfClient Connected!");
        connected = true;
    });

    appClient.on("disconnect", function() {
        console.log("iotfClient Disconnected!");
        connected = false;
    });

    appClient.on("error", function( err) {
    	var errid = nodeuuid.v4();
    	console.error(messages.iotf_error, errid);
    	console.log("Error id " + errid + ". IoTF Error: " + err);
    });
}

iotfClient.publishPayload = function(payload, deviceType, deviceName, event) {
    appClient.publishDeviceEvent(deviceType, deviceName, event, "json", JSON.stringify(payload));
};

iotfClient.publishCommand = function(payload, deviceType, deviceName, command) {
    appClient.publishDeviceCommand(deviceType, deviceName, command, "json", JSON.stringify(payload));
};

iotfClient.publishAction = function(payload, action) {
    appClient.publishDeviceEvent("actionEngine", "action", action, "json", JSON.stringify(payload));
};

//deletes the device from the IoTF platform
//the device argument is an object with the following format
//{
//		deviceId: 'deviceId',
//		deviceType: 'deviceType'
//}
iotfClient.deleteDevice = function(device, callback) {

	console.log("Device: " + JSON.stringify( device));

	var hostname = iotFoundationCredentials.http_host;
	var apiPrefix = 'api/v0002/';
	var api_key = iotFoundationCredentials.apiKey;
	var auth_token = iotFoundationCredentials.apiToken;
	var deviceEndpoint = path.posix.join(apiPrefix, "device/types", device.deviceType, "devices/", device.deviceId);

	//console.log("Hostname: " + hostname);
	//console.log("Endpoint: " + deviceEndpoint);

	// make the delete request to IoTF
	util.httpDeleteCall(hostname, deviceEndpoint, api_key, auth_token, null, null, "", function(err, response) {
		if (err) {
			callback( err, null);
		} else {
        callback( null, response);
		}
	});
}

iotfClient.createDevice = function(payload, callback) {
    var hostname = iotFoundationCredentials.http_host;
    var apiPrefix = 'api/v0002/';

    var deviceTypeEndpoint = path.posix.join(apiPrefix, "/device/types/");
    var api_key = iotFoundationCredentials.apiKey;
    var auth_token = iotFoundationCredentials.apiToken;

    var deviceEndpoint = path.posix.join(apiPrefix, "device/types", payload.deviceType, "devices/");
    var newDevice = {
        deviceId: payload.deviceId
    };

    console.log("hostname: " + hostname);
    console.log("deviceTypeEndpoint: " + deviceTypeEndpoint + payload.deviceType);

    newDevice = JSON.stringify(newDevice);

	// Check if device Type is registered
    util.httpGetCall(hostname, deviceTypeEndpoint + payload.deviceType, api_key, auth_token, null, null, true, function(err, response) {
		if (err) {
			// try to create device type
            var newDeviceType = {id: payload.deviceType};
            newDeviceType = JSON.stringify(newDeviceType);
			util.httpPostCall(hostname, deviceTypeEndpoint, api_key, auth_token, null, null, true, newDeviceType, function(err2, response2) {
					// Creating device
					util.httpPostCall(hostname, deviceEndpoint, api_key, auth_token, null, null, true, newDevice, function(err3, response3) {
						callback(err3, response3);
					});
			});
		} else {
			// Creating device
			util.httpPostCall(hostname, deviceEndpoint, api_key, auth_token, null, null, true, newDevice, function(err4, response4) {
                callback(err4, response4);
			});
		}
    });
};

initIOTClient();

module.exports = iotfClient;
